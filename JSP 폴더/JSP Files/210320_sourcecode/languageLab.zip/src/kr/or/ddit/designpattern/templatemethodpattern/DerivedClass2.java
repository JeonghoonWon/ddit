package kr.or.ddit.designpattern.templatemethodpattern;

public class DerivedClass2 extends TemplateClass{
@Override
protected void stepTwo() {
	System.out.println("2단계_B");
	
}
}
