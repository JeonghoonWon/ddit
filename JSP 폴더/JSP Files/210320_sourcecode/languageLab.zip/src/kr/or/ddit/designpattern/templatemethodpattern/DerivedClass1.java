package kr.or.ddit.designpattern.templatemethodpattern;

public class DerivedClass1 extends TemplateClass{
@Override
protected void stepTwo() {
	System.out.println("2단계_A");
	
}
}
