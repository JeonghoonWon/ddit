package kr.or.ddit.utils;

import java.util.Date;

public class FunctionDate {
	public static Date getNow() {
		return new Date();
	}
}
