package kr.or.ddit.validator;

import javax.validation.groups.Default;

public interface NoticeInsertGroup extends Default {

}
