package kr.or.ddit.board.dao;

public interface IReplyDAO {

}
