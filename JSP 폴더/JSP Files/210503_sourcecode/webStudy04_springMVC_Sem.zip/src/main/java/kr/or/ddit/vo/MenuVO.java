package kr.or.ddit.vo;

import lombok.Data;

@Data
public class MenuVO {
	private String menuURL;
	private String menuText;
	private String menuClass;
	private String menuId;
}
