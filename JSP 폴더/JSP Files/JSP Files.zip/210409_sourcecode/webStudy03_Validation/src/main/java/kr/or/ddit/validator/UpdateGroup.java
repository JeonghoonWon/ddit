package kr.or.ddit.validator;

import javax.validation.groups.Default;

public interface UpdateGroup extends Default{

}
