package kr.or.ddit.enumpkg;

public enum ServiceResult {
	OK, FAIL, NOTEXIST, INVALIDPASSWORD, PKDUPLICATED
}
