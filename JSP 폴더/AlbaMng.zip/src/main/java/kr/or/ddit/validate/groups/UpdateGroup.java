package kr.or.ddit.validate.groups;

import javax.validation.groups.Default;

public interface UpdateGroup extends Default {

}
