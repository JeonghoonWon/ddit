package kr.or.ddit.member.vo;

public class ZipVO {

	private String zipcode;
	private String sido;
	private String gugun;
	private String dong;
	private String bunji;
	
}
