package kr.or.ddit.validator;


public interface DeleteGroup{

}